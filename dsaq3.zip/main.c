#include <stdio.h>

int main()
{
    
    int number,x,k, val_find, found = 0;
    printf("Enter the number of elements that u want to be in the array: ");
    scanf("%d", &number);
    int arr[number];
    printf("Enter the elements sequentially: \n");
    for (k = 0; k< number; k++)
    {
        scanf("%d", &arr[k]);
    }

    printf("Enter the element to be searched: ");
    scanf("%d", &val_find);

    for (x = 0; x< number; x++)
    {
        if (val_find == arr[x])
        {
            found = 1;
            break;
        }
    }
    if (found == 1)
        printf("Element is there in the array at the position %d", x );
    else
        printf("Element isn't  there in the array\n");
        
    return 0;
}