#include <stdio.h>
#include <stdlib.h>
 
typedef struct Binarytree
{
    int data;
    struct Binarytree *l;
    struct Binarytree *r;
} nod;
 
nod *create();
void insert(nod *, nod *);
void preorder(nod *);
void postorder(nod *);
void inorder(nod *);
 
int main()
{
    int var;
    nod*root = NULL, *temp, *current;
    printf("Enter the number of Nodes you want to be in binarytree :");
    scanf("%d", &var);
    printf("Enter %d Nodes data ",var);
    do
    {
        temp = create();
        if (root == NULL)
            root = temp;
        else
            insert(root, temp);
        var--;
 
    } while (var != 0);
 
    printf("Preorder");
    preorder(root);
 
    printf("Inorder");
    inorder(root);
 
    printf("Postorder");
    postorder(root);
 
 
    return 0;
}
 
nod *create()
{
    nod *ano;
 
    ano= (nod *)malloc(sizeof(nod));
    scanf("%d", &ano->data);
    ano->l = ano->r = NULL;
    return ano;
}
 
void insert(nod *root, nod *tre)
{
    if (root == NULL)
    {
        root = tre;
    }
    else
    {
 
        if (tre->data < root->data)
        {
            if (root->l != NULL)
                insert(root->l, tre);
            else
                root->l = tre;
        }
 
        if (tre->data > root->data)
        {
            if (root->r != NULL)
                insert(root->r, tre);
            else
                root->r = tre;
        }
    }
}
 
void preorder(nod *root)
{
    if (root != NULL)
    {
        printf("%d  ", root->data);
        preorder(root->l);
        preorder(root->r);
    }
}
 
void postorder(nod *root)
{
    if (root != NULL)
    {
        postorder(root->l);
        postorder(root->r);
        printf("%d  ", root->data);
    }
}
 
void inorder(nod *root)
{
    if (root != NULL)
    {
        inorder(root->l);
        printf("%d  ", root->data);
        inorder(root->r);
    }
}