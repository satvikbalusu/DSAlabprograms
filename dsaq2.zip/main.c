# include <stdio.h>
#include <stdlib.h>
 
struct node
{
    int value;
    struct node *lft;
    struct node *rgt;
}*root = NULL, *p = NULL, *t;
 

void insert();
void inorder(struct node *t);
void create();
void search(struct node *t);

 
 
void main()
{
    int satvik;
 
    printf("\nOPERATIONS ---");
    printf("\n1 - Insert an element\n");
    printf("2 - Inorder \n");
    printf("3 - Exit\n");
    while(1)
    {
        printf("\nEnter your choice : ");
        scanf("%d", &satvik);
        switch (satvik)
        {
        case 1:    
            insert();
            break;
       
        case 2:    
            inorder(root);
            break;
       
        case 3:    
            exit(0);
          
        }
    }
}
 

void insert()
{
    create();
    if (root == NULL) 
        root = p;
    else    
        search(root);    
}
 

void create()
{
    int mo;
 
    printf("Enter data of node ");
    scanf("%d", &mo);
    p = (struct node *)malloc(1*sizeof(struct node));
    p->value = mo;
    p->lft = p->rgt = NULL;
}
 

void search(struct node *t)
{
    if ((p->value > t->value) && (t->rgt != NULL))      
        search(t->rgt);
    else if ((p->value > t->value) && (t->rgt == NULL))
        t->rgt = p;
    else if ((p->value < t->value) && (t->lft != NULL))   
        search(t->lft);
    else if ((p->value < t->value) && (t->lft == NULL))
        t->lft = p;
}
 

void inorder(struct node *n)
{
    if (root == NULL)
    {
        printf("No elements in tree");
        return;
    }
    if (n->lft != NULL)    
        inorder(n->lft);
    printf("%d -> ", n->value);
    if (n->rgt != NULL)    
        inorder(n->rgt);
}
